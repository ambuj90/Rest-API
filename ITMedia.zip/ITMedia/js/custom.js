$(document).ready(function() {
     'use strict';

     var currentStep = $('.current-step').html();
     var totalStep = $('.total-step').html();
     var next_step = true;

     $(".registration-form").keypress(
          function(event) {
               if (event.which == '13') {
                    event.preventDefault();
               }
          }
     );

     function handleFormValidation(curField, name) {

          switch (name) {
               case 'txtDob':
                    checkDob();
                    break;
               case 'txtZip':
                    checkZip();
                    break;
               case 'txtEmail':
                    checkEmail();
                    break;
               case 'txtPhone':
                    var pNum = $("#txtPhone").val();
                    checkPhone(pNum, "txtPhone");
                    break;
               case 'txtWorkPhone':
                    var pNum = $("#txtWorkPhone").val();
                    checkPhone(pNum, "txtWorkPhone");
                    break;
               case 'txtEmployerPhone':
                    var pNum = $("#txtEmployerPhone").val();
                    checkPhone(pNum, "txtEmployerPhone");
                    break;
               case 'txtSocialSecurityNum':
                    checkSSN();
                    break;
               case 'txtAbaNumber':
                    checkRoutingNumber();
                    break;
                    break;
               case 'txtAccountNumber':
                    checkAccount();
                    break;
               default:
                    console.log("All Good");
                    break;
          }

          //Validate DOB
          function checkDob() {
               var dob = new Date($("#txtDob").val());

               //calculate month difference from current date in time
               var month_diff = Date.now() - dob.getTime();

               //convert the calculated difference in date format
               var age_dt = new Date(month_diff);

               //extract year from date
               var year = age_dt.getUTCFullYear();

               //now calculate the age of the user
               var age = Math.abs(year - 1970);

               if (age <= 18) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }

          }

          //Validate Zip
          function checkZip() {
               var zip = $("#txtZip").val();

               if (zip.length !== 5) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }
          }

          //Validate Email
          function checkEmail() {
               var email = $("#txtEmail").val();
               var regexEmail = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;

               if (!regexEmail.test(email)) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }
          }

          //Validate Phone
          function checkPhone(phone, fieldID) {
               //var phone = $("#txtPhone").val();
               var cleaned = ('' + phone).replace(/\D/g, '');

               if (phone.length !== 10) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }else {
                    var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
                    if (match) {
                         var newPhone = $("#"+ fieldID +"1").val( match[1] + '-' + match[2] + '-' + match[3] );
                    } else {
                         $(curField).addClass('input-error');
                         next_step = false;
                    }
               }

          }

          //Validate SSN
          function checkSSN() {
               var ssn = $("#txtSocialSecurityNum").val();
               //var regexSSN = /^(?!666|000|9\\d{2})\\d{3}" + "-(?!00)\\d{2}-" + "(?!0{4})\\d{4}$/;
               if (ssn.length !== 9) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }
               // if (regexSSN.test(ssn)) {
               //      if (ssn.length !== 9) {
               //           $(curField).addClass('input-error');
               //           next_step = false;
               //      }
               // } else {
               //      $(curField).addClass('input-error');
               //      next_step = false;
               // }
          }

          //Validate Routing Number
          function checkRoutingNumber() {
               var routing = $("#txtAbaNumber").val();

               if (routing.length !== 9) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }

               var checksumTotal = (7 * (parseInt(routing.charAt(0), 10) + parseInt(routing.charAt(3), 10) + parseInt(routing.charAt(6), 10))) +
                    (3 * (parseInt(routing.charAt(1), 10) + parseInt(routing.charAt(4), 10) + parseInt(routing.charAt(7), 10))) +
                    (9 * (parseInt(routing.charAt(2), 10) + parseInt(routing.charAt(5), 10) + parseInt(routing.charAt(8), 10)));

               var checksumMod = checksumTotal % 10;
               if (checksumMod !== 0) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }
          }

          //Validate Account Number
          function checkAccount() {
               var accNum = $("#txtAccountNumber").val();

               if (accNum.length !== 13) {
                    $(curField).addClass('input-error');
                    next_step = false;
               }
          }

     }


     function checkStep() {

          if (currentStep == totalStep) {
               $('.step-count').addClass('final-step');

          } else if (currentStep > totalStep) {
               $('.covid-header').addClass('no-step');
               $('.step-count').removeClass('final-step');

          } else {
               $('.step-count').removeClass('final-step');
               $('.covid-header').removeClass('no-step');
          }

     }

     $('.registration-form input[type="text"], input[type="number"], input[type="email"], input[type="tel"], input[type="radio"], input[type="checkbox"], input[type="date"], select, textarea').on('focus', function() {
          $(this).removeClass('input-error');
     });

     $('.registration-form .button').on('click', function(e) {
          e.preventDefault();

          next_step = true;

          var parent_test_step = $(this).parents('.test-step');

          parent_test_step.find('input[type="text"], input[type="number"], input[type="email"], input[type="tel"], input[type="radio"], input[type="checkbox"], input[type="date"], select, textarea').each(function() {

               if ($(this).val() == "") {
                    $(this).addClass('input-error');
                    next_step = false;
               } else if ($(this).val() != "") {
                    handleFormValidation($(this), $(this).attr('name'));
                    //alert(returnValue);
                    //if(returnValue == 0) next_step = false;
               } else {
                    $(this).removeClass('input-error');
               }
          })

          if (next_step) {
               currentStep++;
               $('.current-step').html(currentStep);
               checkStep();

               $(this).parents('.test-step').next().addClass('active');
               $(this).parents('.test-step').removeClass('active');
          }
     });

     $('.registration-form .prev-btn').on('click', function(e) {

          e.preventDefault();

          currentStep--;
          $('.current-step').html(currentStep);

          checkStep();

          $(this).parents('.test-step').prev().addClass('active');
          $(this).parents('.test-step').removeClass('active');

     });

     // submit
     $('#form1').submit(function(e) {

          e.preventDefault();
          var form = $(this);

          $.ajax({
               type: "POST",
               url: "leadPostApi.php",
               data: form.serialize(), // serializes the form's elements.
               dataType: 'json',
               success: function(data) {
                    var status = data.Status;

                    if (status == "Sold") {
                         var leadID = data.LeadID;
                         var redirectURL = data.Redirect;
                         var price = data.Price;
                         alert(leadID + " " + redirectURL + " " + price);
                         location.href = data.Redirect;
                    } else if (status == "Error") {
                         var messages = data.Messages;
                         alert(messages);
                    } else {
                         var leadID = data.LeadID;
                         var priceRejectAmount = data.PriceRejectAmount;
                         alert(leadID + " " + priceRejectAmount);
                    }
               },
               error: function(status, err) {
                    console.log('Something went wrong', status, err);
               }
          });

     });

})
