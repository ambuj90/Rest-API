<?php
$to_post = array();
$to_post['username']             = 'BlueRibbon_Min.25cents';
$to_post['apikey']               = '707e779dbf5d7d7b2cf86b11c04579830aa426e7';
$to_post['campaignId']           = '1234';
$to_post['ip_address']           = '64.183.123.2';
$to_post['agent']                = 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:10.0) Gecko/20100101 Firefox/10.0';
$to_post['min_price']            = '20';
$to_post['amount']               = '500';
$to_post['fName']                = $_POST["txtName"];
$to_post['lName']                = $_POST["txtLname"];
$to_post['zip']                  = $_POST["txtZip"];
$to_post['city']                 = $_POST["txtCity"];
$to_post['state']                = $_POST["txtState"];
$to_post['address']              = $_POST["txtAdd"];
$to_post['lengthAtAddress']      = $_POST['txtLatAdd'];
$to_post['licenseState']         = $_POST['txtIssuingState'];
$to_post['email']                = $_POST["txtEmail"];
$to_post['license']              = $_POST['txtLicense'];
$to_post['rentOwn']              = $_POST['txtHomeType'];
$to_post['phone']                = $_POST['txtPhone1'];
$to_post['workPhone']            = $_POST['txtWorkPhone1'];
$to_post['callTime']             = $_POST['txtCallTime'];
$to_post['bMonth']               = date("m",strtotime($_POST['txtDob']));
$to_post['bDay']                 = date("d",strtotime($_POST['txtDob']));
$to_post['bYear']                = date("Y",strtotime($_POST['txtDob']));
$to_post['ssn']                  = $_POST['txtSocialSecurityNum'];;
$to_post['armedForces']          = $_POST['txtArmedForces'];;
$to_post['incomeSource']         = $_POST['txtIncomeSource'];
$to_post['employerName']         = $_POST['txtEmployerName'];
$to_post['timeEmployed']         = $_POST['txtTimeEmployed'];
$to_post['employerPhone']        = $_POST['txtEmployerPhone1'];
$to_post['jobTitle']             = $_POST['txtJobTitle'];
$to_post['paidEvery']            = $_POST['txtGetPaid'];
$to_post['nextPayday']           = date('d-m-Y', strtotime($_POST['txtNextPayDate']));
$to_post['secondPayday']         = date('d-m-Y', strtotime($_POST['txtSecPayDate']));
$to_post['abaNumber']            = $_POST['txtAbaNumber'];
$to_post['accountNumber']        = $_POST['txtAccountNumber'];
$to_post['accountType']          = $_POST['txtAccountType'];
$to_post['bankName']             = $_POST['txtBankName'];
//$to_post['bankPhone']            = $_POST[''];
$to_post['monthsBank']           = $_POST['txtMonthsAtBank'];
$to_post['directDeposit']        = $_POST['txtPaidWithDD'];
$to_post['monthlyNetIncome']     = $_POST['txtGrossIncome'];
// $to_post['ownCar']               = 'no';
$to_post['note']                 = 'First Lead';
$to_post['websiteName']          = 'www.itmedia.xyz';
$to_post['timeout']              = '240';
//$to_post['lead_type']            = 'installment';
$to_post['loan_reason']          = $_POST['txtLoanReason'];
$to_post['credit_type']          = $_POST['txtCreditType'];
//$to_post['atrk']                 = 'XYZ123654';
$to_post['unsecuredDebt']        = $_POST['txtUnsecuredDebt'];

$ch = curl_init();
//$posting_url = "https://api.itmedia.xyz/post/testjson/api/v2";
$posting_url = "https://api.itmedia.xyz/post/productionjson/api/v2";


curl_setopt(    $ch,    CURLOPT_URL,               $posting_url             );
curl_setopt(    $ch,    CURLOPT_POST,              1                        );
curl_setopt(    $ch,    CURLOPT_POSTFIELDS,        $to_post                 );
curl_setopt(    $ch,    CURLOPT_FAILONERROR,       1                        );
curl_setopt(    $ch,    CURLOPT_HEADER,            0                        );
curl_setopt(    $ch,    CURLOPT_RETURNTRANSFER,    1                        );
curl_setopt(    $ch,    CURLOPT_SSL_VERIFYPEER,    false                    );
curl_setopt(    $ch,    CURLOPT_SSL_VERIFYHOST,    false                    );
curl_setopt(    $ch,    CURLOPT_TIMEOUT,           0                        );


$ret = curl_exec($ch);
curl_close($ch);


$ret_pkt = json_decode($ret);

/* ret_pkt contains response as described in JSON response */
//var_dump($ret_pkt);

//object(stdClass)#2 (4) {
//["Status"]=> string(4) "Sold"
//    ["LeadID"]=> string(15) "4436567-0508985"
//    ["Redirect"]=> string(44) "http://testurl.com/redirect?id=8494208490233"
//    ["Price"]=> string(2) "20"
//}

echo $ret;


?>
