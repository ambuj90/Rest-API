<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Check your loan eligiblity - Redcred.com</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!-- External Css -->
    <link rel="stylesheet" href="assets/css/line-awesome.min.css">

    <!-- Custom Css -->
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/covid.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- Favicon -->
    <link rel="icon" href="images/favicon.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"/>


  </head>
  <body>

    <div class="ugf-covid covid-bg">
  <div class="container">
        <div class="row">
          <div class="col">
            <nav class="navbar navbar-expand-md anfra-nav">
              <a class="navbar-brand" href="index.html">
                <img src="images/logo.png" class="main-logo" alt="">
                <img src="images/logo-2.png" class="logo-2" alt="">
              </a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="las la-bars"></i>
              </button>

              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                    <a class="nav-link" href="#"><svg class="svg-inline--fa fa-lock text-success" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="lock" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M80 192V144C80 64.47 144.5 0 224 0C303.5 0 368 64.47 368 144V192H384C419.3 192 448 220.7 448 256V448C448 483.3 419.3 512 384 512H64C28.65 512 0 483.3 0 448V256C0 220.7 28.65 192 64 192H80zM144 192H304V144C304 99.82 268.2 64 224 64C179.8 64 144 99.82 144 144V192z"></path></svg><!-- <i class="fa fa-lock text-success"></i> Font Awesome fontawesome.com --> Secured SSL Encryption</a>
                  </li>
                </ul>
              </div>
            </nav>
          </div>
        </div>
      </div>
      <div class="pt100">
        <div class="container">
          <div class="row">
            <div class="col-xl-7 col-lg-7">
              
            </div>
            <div class="col-xl-5  col-lg-5 ">
              <div class="covid-wrap">
                <div class="covid-header">
                  <h2>Provide Your Accourate Information</h2>
                  <span class="step-count"><span class="current-step">1</span>/<span class="total-step">7</span></span>
                </div>
                <form action="#" name="form1" id="form1" class="registration-form">

                   <input type="hidden" name="txtLoanAmount" value="<?php echo $_GET['amount'] ?>">     

                  <div class="covid-test-wrap test-step active">
                    <h3>Loan Request</h3>
                    <div class="step-block">
                      <div class="form-group">
                        <input type="text" class="form-control" name="txtName" id="txtName" placeholder="First Name" required>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" name="txtLname" id="txtLname" placeholder="Last Name" required>
                      </div>
                      <label for="">Date of Birth</label>
                      <div class="form-group">
                        <input type="date" class="form-control" name="txtDob" id="txtDob" value="<?php echo date('Y-m-d', strtotime($_GET['dob']))  ?>" placeholder="Date of Birth" required>
                      </div>
                      <div class="form-group">
                        <input type="email" class="form-control" name="txtEmail" id="txtEmail" value="<?php echo $_GET['email'] ?>" placeholder="Email" required>
                      </div>
                      <a href="#" id="btnNext_1" class="button">Next</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Contact Information</h3>
                    <p>We're here to help with your Auto Purchase loan request.</p>
                    <div class="step-block">
                      <div class="form-group">
                        <input type="text" class="form-control" name="txtAdd" id="txtAdd" placeholder="Address" required>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" name="txtAdd1" id="txtAdd1" placeholder="Address Line 2">
                      </div>
                      <div class="form-group">
                        <input type="number" class="form-control" name="txtZip" id="txtZip" value="<?php echo $_GET['zip'] ?>" placeholder="Zip Code" required>
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" name="txtCity" id="txtCity" placeholder="City" required>
                      </div>
                      <div class="form-group">
                        <select class="form-control" name="txtState" id="txtState" required>
                             <option value="">Select State</option>
                             <option value="CA">Canada</option>
                             <option value="USA">United State of America</option>
                        </select>
                      </div>
                      
                      <div class="form-group">
                        <input type="number" class="form-control" name="txtPhone" id="txtPhone" placeholder="Phone" required>
                        <input type="hidden" class="form-control" name="txtPhone1" id="txtPhone1" placeholder="Phone" required>
                      </div>
                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Contact Information</h3>
                    <p>Help us to Auto Purchase your loan request.</p>
                    <div class="step-block">
                      <div class="form-group">
                           <select class="form-control" name="txtLatAdd" id="txtLatAdd" required>
                                <option value="">Length At Address</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                           </select>
                      </div>
                      <div class="form-group">
                        <input type="radio" class="form-control" name="txtHomeType" id="txtOwnHome" value="own" checked>
                        <label for="txtOwnHome">Your own home? </label>
                      </div>
                      <div class="form-group">
                           <input type="radio" class="form-control" name="txtHomeType" id="txtRentHome" value="rent">
                           <label for="txtRentHome">Living on rent? </label>
                      </div>
                      <div class="form-group">
                           <select class="form-control" name="txtCallTime" id="txtCallTime" required>
                                <option value="">Select Call Time</option>
                                <option value="anytime">Anytime</option>
                                <option value="morning">Morning</option>
                                <option value="afternoon">Afternoon</option>
                                <option value="evening">Evening</option>
                           </select>
                      </div>
                      <div class="form-group">
                        <input type="number" class="form-control" name="txtWorkPhone" id="txtWorkPhone" placeholder="Work Phone" required>
                        <input type="hidden" class="form-control" name="txtWorkPhone1" id="txtWorkPhone1" placeholder="Phone" required>
                      </div>
                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>

                  <div class="covid-test-wrap test-step">
                    <h3>Employment</h3>
                    <p>Next, tell us more about your employment.</p>
                    <div class="step-block">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                               <select class="form-control" name="txtIncomeSource" id="txtIncomeSource"  required>
                                   <option value="">Select Income Source</option>
                                   <option value="employment">Employment</option>
                                   <option value="selfemployment">Self Employment</option>
                                   <option value="benefits">Benefits</option>
                                   <option value="unemployed">Unemployed</option>
                              </select>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                               <select class="form-control" name="txtTimeEmployed" id="txtTimeEmployed" required>
                                  <option value="">Time Employed</option>
                                  <option value="1">Less than 1 year</option>
                                  <option value="2">1 to 2 years</option>
                                  <option value="3">2 to 5 years</option>
                                  <option value="4">Above 5 years</option>
                             </select>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                           <select class="form-control" name="txtGetPaid" id="txtGetPaid" required>
                             <option value="">I Get Paid</option>
                             <option value="biweekly">Bi Weekly</option>
                             <option value="weekly">Weekly</option>
                             <option value="monthly">Monthly</option>
                             <option value="twicemonthly">Twice monthly</option>
                         </select>
                      </div>
                      <div class="form-group">
                        <input type="radio" class="form-control" name="txtArmedForces" id="txtArmedForcesYes" value="yes">
                        <label for="txtArmedForcesYes">Yes, I'm in Military. </label>
                      </div>
                      <div class="form-group">
                           <input type="radio" class="form-control" name="txtArmedForces" id="txtArmedForcesNo" value="no" checked>
                           <label for="txtArmedForcesNo">No, I'm not in Military. </label>
                      </div>

                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Employment</h3>
                    <p>You have been employed for 2 years and get paid once a month.</p>
                    <div class="step-block">
                         <div class="form-group">
                             <input type="text" class="form-control" name="txtEmployerName" id="txtEmployerName" placeholder="Employer Name" required>
                         </div>
                         <div class="form-group">
                             <input type="number" class="form-control" name="txtEmployerPhone" id="txtEmployerPhone" placeholder="Employer Phone" required>
                             <input type="hidden" class="form-control" name="txtEmployerPhone1" id="txtEmployerPhone1" placeholder="Phone" required>
                         </div>
                         <div class="form-group">
                             <input type="text" class="form-control" name="txtJobTitle" id="txtJobTitle" placeholder="Job Title" required>
                         </div>
                         <div class="form-group">
                          <input type="number" class="form-control" name="txtGrossIncome" id="txtGrossIncome" placeholder="Monthly Pre-Tax Income" required>
                        </div>
                        <label for="">Select Next Pay Date</label>
                        <div class="form-group">
                          <input type="date" class="form-control" name="txtNextPayDate" id="txtNextPayDate" placeholder="Select Next Pay Date" required>
                        </div>
                        <label for="">Select Second Pay Date</label>
                        <div class="form-group">
                          <input type="date" class="form-control" name="txtSecPayDate" id="txtSecPayDate" placeholder="Select Second Pay Date" required>
                        </div>

                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Employement</h3>
                    <p>Please help us verify your identity.</p>
                    <div class="step-block">
                         <div class="form-group">
                             <input type="text" class="form-control" name="txtLicense" id="txtLicense" placeholder="Driever's Licence or State ID" required>
                         </div>
                         <div class="form-group">
                              <select class="form-control" name="txtIssuingState" id="txtIssuingState" required>
                                  <option value="">Select Issuing State</option>
                                  <option value="USA">United State</option>
                                  <option value="CA">Canada</option>
                             </select>
                         </div>
                         <div class="form-group">
                             <input type="number" class="form-control" name="txtSocialSecurityNum" id="txtSocialSecurityNum" placeholder="Social Security Number?" required>
                         </div>
                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Banking</h3>
                    <p>Your request is almost complete.</p>
                    <div class="step-block">

                      <div class="row">
                         <label for="">What type of bank account do you have?</label>
                        <div class="col-sm-6">
                           <div class="form-group">
                             <input type="radio" name="txtAccountType" class="form-control" id="txtAccountChecking" value="checking" checked>
                             <label for="txtAccountChecking">Checking</label>
                           </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                              <input type="radio" name="txtAccountType" class="form-control" id="txtAccountSaving" value="saving">
                              <label for="txtAccountSaving">Saving</label>
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                          <input type="text" class="form-control" name="txtBankName" id="txtBankName" placeholder="Bank Name?" required>
                      </div>
                      <div class="row">
                        <label for="">Are you paid with direct deposit or paper check?</label>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <input type="radio" name="txtPaidWithDD" id="txtPaidWithDD" value="yes" class="form-control" checked>
                            <label for="txtPaidWithDD">Direct Deposit</label>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <input type="radio" name="txtPaidWithDD" id="txtPaidWithPaperCheck" value="no" class="form-control">
                            <label for="txtPaidWithPaperCheck">Paper Check</label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                           <select class="form-control" name="txtMonthsAtBank" id="txtMonthsAtBank">
                               <option value="">Select Months At bank</option>
                               <option value="1">Less than 1 year</option>
                               <option value="3">1 to 3 year</option>
                          </select>
                      </div>
                      <!-- <p class="error-msg">* Select at least one option</p> -->
                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Banking</h3>
                    <p>Your request is almost complete.</p>
                    <div class="step-block">
                      <label for="">Which bank account will receive your loan?</label>
                      <div class="form-group">
                        <input type="number" name="txtAbaNumber" id="txtAbaNumber" class="form-control" placeholder="ABA / Routing Number">
                      </div>
                      <div class="form-group">
                        <input type="number" name="txtAccountNumber" id="txtAccountNumber" class="form-control" placeholder="Account Number">
                      </div>
                      <div class="form-group">
                        <img src="images/cheque.jpg" alt="">
                      </div>

                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Credit Information</h3>
                    <p>Almost there, let's do this!</p>
                    <div class="step-block">
                         <div class="form-group">
                              <select class="form-control" name="txtLoanReason" id="txtLoanReason" required>
                               <option value="">SelectLoan Reason</option>
                               <option value="debtConsolidation">Debt Consolidation</option>
                               <option value="emergencySituation">Emergency Situation</option>
                               <option value="autoRepair">Auto Repair</option>
                               <option value="autoPurchase">Auto Purchase</option>
                               <option value="moving">Moving</option>
                               <option value="homeImprovement">Home Improvement</option>
                               <option value="medical">Medical</option>
                               <option value="business">Business</option>
                               <option value="vacation">Vacation</option>
                               <option value="taxes">Taxes</option>
                               <option value="rentOrMortgage">Rent Or Mortgage</option>
                               <option value="wedding">Wedding</option>
                               <option value="majorPurchase">MajorPurchase</option>
                               <option value="other">Other</option>
                              </select>
                         </div>
                          <div class="form-group">
                               <select class="form-control" name="txtCreditType" id="txtCreditType" required>
                                 <option value="">Select Credit Type</option>
                                 <option value="excellent">Excellent</option>
                                 <option value="good">Good</option>
                                 <option value="fair">Fair</option>
                                 <option value="poor">Poor</option>
                                 <option value="notSure">Not Sure</option>
                               </select>
                          </div>
                          <div class="form-group">
                              <input type="text" name="txtUnsecuredDebt" id="txtUnsecuredDebt" class="form-control" placeholder="Unsecured debt does you have?">
                          </div>


                      <a href="#" class="button">Next</a>
                      <a href="#" class="prev-btn"><img src="images/arrow-left-grey.png" alt="">Previous</a>
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step">
                    <h3>Credit Information</h3>
                    <p>Last questions, almost done!</p>
                    <div class="step-block">

                          <div class="form-group">
                            <input type="radio" name="chkAddLender" class="form-control" id="chkAddLender" required checked>
                            <label for="chkAddLender">Yes, access additional lenders</label>
                          </div>

                          <div class="form-group">
                            <input type="radio" name="chkCrOffer" class="form-control" id="chkCrOffer" required checked>
                            <label for="chkCrOffer">Yes, other credit-related offers</label>
                          </div>
                          <div class="form-group">
                            <input type="radio" name="chkAuth" class="form-control" id="chkAuth" required checked>
                            <label for="chkAuth">I agree</label>
                          </div>


                      <input type="submit" value="Submit info" class="btnSubmit" />
                    </div>
                  </div>
                  <div class="covid-test-wrap test-step thankyou-sec">
                    <div class="test-progress">
                      <img src="images/big-green-check.png" class="img-fluid" alt="">
                    </div>
                    <h3>Thank you for submission</h3>
                    <p>Congratulations! These are the options for you.</p>
                    <!-- <h4>Stay Home &nbsp; &nbsp;<span class="line">&#73;</span> &nbsp; &nbsp; Stay Safe</h4> -->
                    <a href="index.html" class="button-reload">Visit Now!</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="footer">
              <div class="footer-social">
                <a href="#"><i class="lab la-facebook-f"></i></a>
                <a href="#"><i class="lab la-twitter"></i></a>
                <a href="#"><i class="lab la-linkedin-in"></i></a>
                <a href="#"><i class="lab la-youtube"></i></a>
                <a href="#"><i class="lab la-instagram"></i></a>
              </div>
              <div class="copyright-text">
                <p>Copyright © 2022 Radcred.com, All rights reserved</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/js/all.min.js"></script>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="js/custom.js"></script>

  </body>
</html>
