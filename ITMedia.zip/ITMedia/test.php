<!-- username            : BlueRibbon
apikey              : 707e779dbf5d7d7b2cf86b11c04579830aa426e7
campaignId          : 1234
ip_address          : 64.183.123.2
agent               : Mozilla/5.0 (X11 Ubuntu Linux i686 rv:10.0) Gecko/20100101 Firefox/10.0
min_price           : 20
amount              : 500
fName               : Joe
lName               : Smith
zip                 : 43209
city                : Los Angeles
state               : CA
address             : 2125 Sawtelle Boulevard
lengthAtAddress     : 1
licenseState        : AL
email               : test@test.com
license             : 65465454
rentOwn             : rent
phone               : 310-867-5309
workPhone           : 310-867-5309
callTime            : anytime
bMonth              : 1
bDay                : 31
bYear               : 1982
ssn                 : 123-23-1234
armedForces         : no
incomeSource        : employment
employerName        : Google
timeEmployed        : 1
employerPhone       : 310-867-5309
jobTitle            : Programmer
paidEvery           : biweekly
nextPayday          : 02-01-2012
secondPayday        : 16-01-2012
abaNumber           : 123123123
accountNumber       : 321321321
accountType         : checking
bankName            : Wells Fargo
bankPhone           : 323-867-5309
monthsBank          : 1
directDeposit       : yes
monthlyNetIncome    : 2750
ownCar              : no
note                :
websiteName         : www.itmedia.xyz
timeout             : 240
lead_type           : installment
loan_reason         : majorPurchase
credit_type         : good
atrk                : XYZ123654
unsecuredDebt       : 10000 -->

// Create connection
$conn = new mysqli($149.28.87.71, $suwtgfcadr, $7VefaXPUjB);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


<?php
// echo date("d",strtotime("10-05-2022"));
// echo date("m",strtotime("10-05-2022"));
// echo date("Y",strtotime("10-05-2022"));

//echo date('d-m-Y', strtotime("2022-05-10"));


// INSERT INTO Customers (
// leadID = $_POST['leadID'],
// Name    = $_POST['txtName'],
// Lname   = $_POST['txtLname'],
// Dob  = $_POST['txtDob'],
// Add   = $_POST['txtAdd'],
// Add1    = $_POST['txtAdd1'],
// Zip   = $_POST['txtZip'],
// City    = $_POST['txtCity'],
// State   = $_POST['txtState'],
// Email   = $_POST['txtEmail'],
// Phone  = $_POST['txtPhone'],
// LatAdd    = $_POST['txtLatAdd'],
// HomeType    = $_POST['txtHomeType'],
// CallTime    = $_POST['txtCallTime'],
// IncomeSource    = $_POST['txtIncomeSource'],
// TimeEmployed    = $_POST['txtTimeEmployed'],
// GetPaid   = $_POST['txtGetPaid'],
// ArmedForces   = $_POST['txtArmedForces'],
// EmployerName    = $_POST['txtEmployerName'],
// EmployerPhone   = $_POST['txtEmployerPhone'],
// JobTitle    = $_POST['txtJobTitle'],
// GrossIncome   = $_POST['txtGrossIncome'],
// NextPayDate   = $_POST['txtNextPayDate'],
// SecPayDate    = $_POST['txtSecPayDate'],
// License   = $_POST['txtLicense'],
// IssuingState    = $_POST['txtIssuingState'],
// SocialSecurityNum   = $_POST['txtSocialSecurityNum'],
// AccountType   = $_POST['txtAccountType'],
// BankName    = $_POST['txtBankName'],
// PaidWithDD    = $_POST['txtPaidWithDD'],
// MonthsAtBank    = $_POST['txtMonthsAtBank'],
// AbaNumber = $_POST['txtAbaNumber'],
// AccountNumber  = $_POST['txtAccountNumber'],
// LoanReason    = $_POST['txtLoanReason'],
// CreditType    = $_POST['txtCreditType'],
// UnsecuredDebt   = $_POST['txtUnsecuredDebt'],
// createdBy   = $_POST['leadID'],
// updatedBy   = $_POST['leadID'],
// status = 1);

$ip = getenv('HTTP_CLIENT_IP')?:
getenv('HTTP_X_FORWARDED_FOR')?:
getenv('HTTP_X_FORWARDED')?:
getenv('HTTP_FORWARDED_FOR')?:
getenv('HTTP_FORWARDED')?:
getenv('REMOTE_ADDR');
echo $ip;


 ?>
