<!DOCTYPE html>
<html>
<body>

<?php 
$x = "Hello world!";
$y = 'Hello world!';

echo $x;
echo "<br>"; 
echo $y;

echo "<br>"; 
$Name = "My name is Ambuj Sharma";
echo $Name;

echo "<br>"; 
$x1 = 5985;
var_dump($x1);
?>

</body>
</html>