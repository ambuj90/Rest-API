<?php
//include_once('config.php');

$servername = "149.28.87.71";
$username = "suwtgfcadr";
$password = "7VefaXPUjB";
$dbname = "suwtgfcadr";

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}else {
     echo "Rohit";
}

$LeadID="5665165";
$Status="Reject";
$Redirect="www.rohit.com";
$Price=50;
$PriceRejectAmount=20;
$Messages="Reject due to high price";

$sql = "INSERT INTO lead_response(leadID, lStatus, lRedirect, lPrice, lPriceRejectAmount, lMessage, createdBy, updatedBy) VALUES('$LeadID', '$Status', '$Redirect', $Price, $PriceRejectAmount, '$Messages', '$LeadID','RadCred')";

if ($conn->query($sql) === TRUE) {
     echo "New record created successfully";
     //echo $ret;
} else {
     echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

 ?>
