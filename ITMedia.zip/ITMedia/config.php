<?php

$servername = "localhost";
$username = "suwtgfcadr";
$password = "7VefaXPUjB";
$dbname = "suwtgfcadr";

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

 ?>
